module.exports = {
    db: {
       userName: "",
       password: "",
       cluster: "",
    },
    port: 3001,
    client: "" //[프로젝트]-[실행 URL과 포트]에서 설정하신 client domain을 넣어주세요!
}