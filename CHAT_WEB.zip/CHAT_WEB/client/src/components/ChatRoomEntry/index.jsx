import ChatRoomEntry from './ChatRoomEntry';

export default ChatRoomEntry;